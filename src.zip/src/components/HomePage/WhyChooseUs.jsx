import { FaCarCrash } from "react-icons/fa";
import { GiCarDoor } from "react-icons/gi";

export default function WhyChooseUs() {
  const services = [
    {
      icon: <GiCarDoor className="text-[40px] text-pink" />,
      title: "Paintless Dent Removal",
      desc: "Flawless, expert repairs to restore your car’s perfect finish.",
    },
    {
      image: "/spray.png",
      title: "Professional Painting",
      desc: "Professional paintwork designed to match or refresh your vehicle.",
    },
    {
      image: "/spray.png",
      title: "Spray Gun Works",
      desc: "Trusted technicians keeping your car in shape.",
    },
    {
      icon: <FaCarCrash className="text-[40px] text-pink" />,
      title: "Damage Repairs",
      desc: "Quick, reliable fixes for minor accident damage.",
    },
  ];

  return (
    <section
      id="why-choose-us"
      className="py-20 bg-white relative overflow-hidden"
    >
      {/* Dotted background */}
      <div
        className="absolute inset-0 bg-[radial-gradient(var(--color-lime)_2px,transparent_2px)] [background-size:20px_20px]"
        style={{
          WebkitMaskImage:
            "linear-gradient(135deg, black 0%, transparent 40%, transparent 60%, black 100%)",
          WebkitMaskRepeat: "no-repeat",
          WebkitMaskSize: "cover",
          maskImage:
            "linear-gradient(135deg, black 0%, transparent 40%, transparent 60%, black 100%)",
          maskRepeat: "no-repeat",
          maskSize: "cover",
        }}
      />

      {/* Floating icons */}
      <div className="absolute inset-0 overflow-hidden z-0">
        <GiCarDoor
          className="bg-icon w-20 h-20 top-8 left-8 text-pink"
          style={{ animationDelay: "0s" }}
        />
        <FaCarCrash
          className="bg-icon w-24 h-24 bottom-8 right-8 text-pink"
          style={{ animationDelay: "15s" }}
        />
      </div>

      {/* Main content */}
      <div className="max-w-6xl mx-auto px-6 text-center relative z-10">
        {/* Header */}
        <h2 className="text-4xl font-bold text-pink mb-4" data-aos="fade-up">
          Why Choose Us
        </h2>
        <p
          className="text-lg text-gray-600 mb-12"
          data-aos="fade-up"
          data-aos-delay="200"
        >
          Recognised for award-winning service, certified quality, and 5-star
          customer satisfaction.
        </p>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {services.map((service, index) => (
            <div
              key={index}
              className="flex flex-col items-center p-6 rounded-2xl border border-pink hover:shadow-pink transition-all duration-300"
              data-aos="zoom-in-up"
              data-aos-delay={index * 150}
            >
              <div className="w-[80px] h-[80px] rounded-full mb-4 flex items-center justify-center bg-lime">
                {service.image ? (
                  <img
                    loading="lazy"
                    src={service.image}
                    alt={service.title}
                    className="w-[65px] h-[65px] object-contain"
                  />
                ) : (
                  service.icon
                )}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {service.title}
              </h3>
              <p className="text-sm text-gray-600">{service.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
